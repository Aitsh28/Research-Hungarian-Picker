/**
 * Hungarian Picker — Client Prototype App Logic
 * Reflects selected organization from Sign In / Sign Up across all pages
 */

const ORG_MAP = {
  'COMMITS': {
    code: 'COMMITS',
    short: 'COMMITS',
    full: 'Commonwealth Information Technology Society (COMMITS)',
    cycle: 'Cycle 2026-A · simulated test case'
  },
  'VOX_NOVA': {
    code: 'VOX_NOVA',
    short: 'Vox Nova',
    full: 'Vox Nova',
    cycle: 'Cycle 2026-B · general recruitment'
  },
  'Vox Nova': {
    code: 'VOX_NOVA',
    short: 'Vox Nova',
    full: 'Vox Nova',
    cycle: 'Cycle 2026-B · general recruitment'
  },
  'JMS': {
    code: 'JMS',
    short: 'JMS',
    full: 'Junior Marketing Society (JMS)',
    cycle: 'Cycle 2026-MKT · committee screening'
  },
  'MUSA': {
    code: 'MUSA',
    short: 'MUSA',
    full: 'Mag-aaral ng Unibersidad sa Sining at Adhika (MUSA)',
    cycle: 'Cycle 2026-ARTS · talent placement'
  }
};

function getActiveOrg() {
  const params = new URLSearchParams(window.location.search);
  const paramOrg = params.get('org') || params.get('organization');
  if (paramOrg && ORG_MAP[paramOrg]) {
    localStorage.setItem('hp_active_org', paramOrg);
    return ORG_MAP[paramOrg];
  }
  const stored = localStorage.getItem('hp_active_org');
  if (stored && ORG_MAP[stored]) {
    return ORG_MAP[stored];
  }
  return ORG_MAP['COMMITS'];
}

function renderOrgState(org) {
  if (!org) return;

  // 1. Update static brand text in navbar: "Hungarian Picker · <ORG>"
  const navOrgElem = document.getElementById('navOrgDisplay');
  if (navOrgElem) {
    navOrgElem.textContent = org.short;
  }

  // 2. Update dashboard header subtitle if on dashboard
  const subtitleElem = document.getElementById('dashboardOrgSubtitle');
  if (subtitleElem) {
    subtitleElem.textContent = `Organization: ${org.short} · Recruitment cycle: ${org.cycle}`;
  }

  // 3. Update profile dropdown text
  const profileOrgElems = document.querySelectorAll('.profile-org-display');
  profileOrgElems.forEach(el => {
    el.textContent = `${org.short} · PUP Quezon City`;
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const activeOrg = getActiveOrg();
  renderOrgState(activeOrg);

  // Sign-in page form submission handler
  const signinForm = document.getElementById('signinForm');
  if (signinForm) {
    const orgSelect = document.getElementById('organization');
    if (orgSelect) {
      const saved = localStorage.getItem('hp_active_org');
      if (saved && orgSelect.querySelector(`option[value="${saved}"]`)) {
        orgSelect.value = saved;
      }
      signinForm.addEventListener('submit', () => {
        localStorage.setItem('hp_active_org', orgSelect.value);
      });
    }
  }

  // Sign-up page form submission handler
  const signupForm = document.getElementById('signupForm');
  if (signupForm) {
    const orgSelect = document.getElementById('organization');
    if (orgSelect) {
      signupForm.addEventListener('submit', () => {
        if (orgSelect.value) {
          localStorage.setItem('hp_active_org', orgSelect.value);
        }
      });
    }
  }
});
